<div class="content-box">
    <div class="content-box-main">

        <h1 style="padding-left:10px;">
            {{ lang._('Device Monitor') }}
            <small id="settings-version" style="font-size:13px;color:#888;margin-left:5px;"></small>
            <span style="color:#555;margin:0 8px;">–</span>
            <span style="font-weight:normal;font-size:18px;">{{ lang._('Settings') }}</span>
        </h1>

        <ul class="nav nav-tabs" role="tablist" style="margin:10px 0 0 0;">
            <li role="presentation" class="active">
                <a href="#tab-email" role="tab" data-toggle="tab">
                    <i class="fa fa-envelope-o"></i> {{ lang._('Email Notifications') }}
                </a>
            </li>
            <li role="presentation">
                <a href="#tab-webhook" role="tab" data-toggle="tab">
                    <i class="fa fa-bell-o"></i> {{ lang._('Webhook Notifications') }}
                </a>
            </li>
            <li role="presentation">
                <a href="#tab-other" role="tab" data-toggle="tab">
                    <i class="fa fa-cog"></i> {{ lang._('Other Settings') }}
                </a>
            </li>
            <li role="presentation">
                <a href="#tab-about" role="tab" data-toggle="tab">
                    <i class="fa fa-info-circle"></i> {{ lang._('About') }}
                </a>
            </li>
        </ul>

        <div class="tab-content" style="padding:15px 0;">

            <!-- TAB 1: Email -->
            <div role="tabpanel" class="tab-pane active" id="tab-email">
                <div class="alert alert-info">
                    {{ lang._('Configure email notifications for new devices on the network') }}
                </div>
                <table class="table table-striped">
                    <tbody>
                        <tr>
                            <td style="width:30%;vertical-align:top;">
                                <label>
                                    <input type="checkbox" id="email_enabled" />
                                    <strong>{{ lang._('Enable Email') }}</strong>
                                </label>
                            </td>
                            <td>
                                <div id="email_config">
                                    <label>{{ lang._('Email Recipient') }}:</label>
                                    <input type="email" id="email_to" class="form-control" placeholder="admin@example.com" style="max-width:400px;" />
                                    <small class="text-muted">{{ lang._('Where to send notifications') }}</small>
                                    <br><br>
                                    <label>{{ lang._('Email Sender') }}:</label>
                                    <input type="email" id="email_from" class="form-control" placeholder="devicemonitor@opnsense.local" style="max-width:400px;" />
                                    <small class="text-muted">{{ lang._('From address') }}</small>
                                    <div class="alert alert-warning" style="margin-top:12px;">
                                        <h4><i class="fa fa-exclamation-triangle"></i> {{ lang._('Important - SMTP Configuration') }}</h4>
                                        <p>{{ lang._('Plugin uses <strong>sendmail (Postfix)</strong> to send emails') }}</p>
                                        <p>{{ lang._('Must be configured in: <strong>System > Settings > Notifications > SMTP</strong>') }}</p>
                                    </div>
                                    <button type="button" id="btn-test-email" class="btn btn-default btn-sm">
                                        🧪 {{ lang._('Test Email') }}
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align:top;padding-top:16px;">
                                <strong>{{ lang._('Notify for interfaces') }}</strong>
                            </td>
                            <td>
                                <small class="text-muted">{{ lang._('Leave empty to receive notifications from all interfaces') }}</small>
                                <div style="margin-top:6px;border:1px solid #444;border-radius:4px;padding:8px;max-width:350px;max-height:180px;overflow-y:auto;" id="email-vlan-list"></div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div style="padding:10px 0 0 0;">
                    <button type="button" class="btn btn-primary btn-apply" id="btn-apply-email">
                        <i class="fa fa-check"></i> {{ lang._('Apply') }}
                    </button>
                </div>
            </div>

            <!-- TAB 2: Webhook -->
            <div role="tabpanel" class="tab-pane" id="tab-webhook">
                <div class="alert alert-info">
                    {{ lang._('Configure webhook notifications for new devices on the network') }}
                </div>
                <table class="table table-striped">
                    <tbody>
                        <tr>
                            <td style="width:30%;vertical-align:top;">
                                <label>
                                    <input type="checkbox" id="webhook_enabled" />
                                    <strong>{{ lang._('Enable Webhook') }}</strong>
                                </label>
                            </td>
                            <td>
                                <div id="webhook_config">
                                    <label>{{ lang._('Webhook URL') }}:</label>
                                    <input type="text" id="webhook_url" class="form-control" placeholder="https://ntfy.sh/your_topic" style="max-width:500px;" />
                                    <div style="margin-top:10px;padding:12px;background:#f8f9fa;border-left:4px solid #007bff;border-radius:4px;max-width:500px;">
                                        <div style="font-weight:600;color:#495057;margin-bottom:8px;">💡 Examples:</div>
                                        <div style="display:flex;flex-direction:column;gap:6px;">
                                            <div><span style="display:inline-block;background:#e3f2fd;color:#1976d2;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;margin-right:8px;">ntfy.sh</span><code>https://ntfy.sh/opnsense_monitor</code></div>
                                            <div><span style="display:inline-block;background:#ede7f6;color:#5e35b1;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;margin-right:8px;">Discord</span><code>https://discord.com/api/webhooks/...</code></div>
                                            <div><span style="display:inline-block;background:#e8f5e9;color:#388e3c;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;margin-right:8px;">Custom</span><code>https://your-server.com/webhook</code></div>
                                        </div>
                                    </div>
                                    <br>
                                    <button type="button" id="test_webhook" class="btn btn-default btn-sm">
                                        🧪 {{ lang._('Send Test') }}
                                    </button>
                                    <span id="webhook_test_result" style="margin-left:10px;font-weight:bold;"></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align:top;padding-top:16px;">
                                <strong>{{ lang._('Notify for interfaces') }}</strong>
                            </td>
                            <td>
                                <small class="text-muted">{{ lang._('Leave empty to receive notifications from all interfaces') }}</small>
                                <div style="margin-top:6px;border:1px solid #444;border-radius:4px;padding:8px;max-width:350px;max-height:180px;overflow-y:auto;" id="webhook-vlan-list"></div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div style="padding:10px 0 0 0;">
                    <button type="button" class="btn btn-primary btn-apply" id="btn-apply-webhook">
                        <i class="fa fa-check"></i> {{ lang._('Apply') }}
                    </button>
                </div>
            </div>

            <!-- TAB 3: Other Settings -->
            <div role="tabpanel" class="tab-pane" id="tab-other">
                <table class="table table-striped">
                    <tbody>
                        <tr>
                            <td style="width:30%;"><strong>{{ lang._('Enable Monitoring') }}</strong></td>
                            <td>
                                <input type="checkbox" id="enabled" />
                                <small class="text-muted" style="margin-left:8px;">{{ lang._('Enable automatic network monitoring') }}</small>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>{{ lang._('Scan Interval') }}</strong></td>
                            <td>
                                <div style="display:flex;align-items:center;gap:10px;">
                                    <input type="number" id="scan_interval" class="form-control" value="300" min="60" max="3600" style="max-width:120px;" />
                                    <span class="text-muted">{{ lang._('seconds') }}</span>
                                </div>
                                <small class="text-muted">{{ lang._('Seconds between scans (60-3600)') }}</small>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div style="padding:10px 0 0 0;">
                    <button type="button" class="btn btn-primary btn-apply" id="btn-apply-other">
                        <i class="fa fa-check"></i> {{ lang._('Apply') }}
                    </button>
                </div>
            </div>

            <!-- TAB 4: About -->
            <div role="tabpanel" class="tab-pane" id="tab-about">
                <div style="max-width:600px;padding:10px 0;">
                    <h3 style="margin-top:0;">{{ lang._('Device Monitor') }} <span id="about-version" style="color:#888;font-size:16px;"></span></h3>
                    <p class="text-muted">{{ lang._('OPNsense plugin for monitoring network devices using the native hostwatch database.') }}</p>
                    <table class="table table-condensed" style="margin-top:20px;">
                        <tr>
                            <td style="width:40%;color:#888;">{{ lang._('Author') }}</td>
                            <td>Hacesoft</td>
                        </tr>
                        <tr>
                            <td style="color:#888;">{{ lang._('GitHub Repository') }}</td>
                            <td><a href="https://github.com/hacesoft/opnsense-devicemonitor" target="_blank">github.com/hacesoft/opnsense-devicemonitor</a></td>
                        </tr>
                        <tr>
                            <td style="color:#888;">{{ lang._('License') }}</td>
                            <td>MIT</td>
                        </tr>
                        <tr>
                            <td style="color:#888;">{{ lang._('Requires OPNsense') }}</td>
                            <td>&ge; 26.1.5</td>
                        </tr>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
$().ready(function() {
    var translations = {
        config_saved:  '{{ lang._('Configuration saved') }}',
        config_error:  '{{ lang._('Error saving configuration') }}',
        test_sent:     '{{ lang._('Test email sent to') }}',
        test_failed:   '{{ lang._('Failed to send email') }}',
        saving:        '{{ lang._('Saving...') }}'
    };

    var allVlanNames = {};

    function showToast(msg, type) {
        var bg = type==='success'?'#4CAF50':(type==='error'?'#f44336':'#2196F3');
        var ic = type==='success'?'fa-check-circle':(type==='error'?'fa-exclamation-circle':'fa-info-circle');
        var $t = $('<div>').css({position:'fixed',top:'20px',right:'20px','background-color':bg,color:'white',
            padding:'15px 20px','border-radius':'4px','box-shadow':'0 4px 8px rgba(0,0,0,.3)',
            'z-index':9999,'min-width':'280px',display:'none'})
            .html('<i class="fa '+ic+'"></i> '+msg);
        $('body').append($t); $t.fadeIn(300);
        setTimeout(function(){ $t.fadeOut(300,function(){ $t.remove(); }); },3000);
    }

    // Version
    $.getJSON('/api/devicemonitor/config/getversion', function(d) {
        var v = 'v'+(d.version||'?');
        $('#settings-version').text(v);
        $('#about-version').text(v);
    });

    // Build VLAN checklist in a container
    function buildVlanCheckList(containerId, selectedVlans) {
        var $c = $('#'+containerId).empty();
        var vlans = Object.keys(allVlanNames).sort();
        if (!vlans.length) {
            $c.html('<em style="color:#888;font-size:12px;">{{ lang._('No interfaces found') }}</em>');
            return;
        }
        var sel = selectedVlans ? selectedVlans.split(',').map(function(v){return v.trim();}).filter(Boolean) : [];
        vlans.forEach(function(v) {
            var n = allVlanNames[v];
            var label = (n && n !== v) ? v+' \u2013 '+n : v;
            var chk = (sel.length === 0) || (sel.indexOf(v) !== -1);
            $c.append($('<label>').css({display:'block',margin:'3px 0',fontWeight:'normal',cursor:'pointer'}).append(
                $('<input type="checkbox" class="notif-vlan-cb">').val(v).prop('checked',chk),
                $('<span>').css('margin-left','8px').text(label)
            ));
        });
    }

    function getSelectedVlans(containerId) {
        var sel=[], total=$('#'+containerId+' .notif-vlan-cb').length;
        $('#'+containerId+' .notif-vlan-cb:checked').each(function(){ sel.push($(this).val()); });
        return (sel.length===total) ? '' : sel.join(',');
    }

    function loadConfig() {
        $.ajax({ url:'/api/devicemonitor/config/get', type:'GET', success:function(d) {
            $('#enabled').prop('checked', d.enabled==='1');
            $('#scan_interval').val(d.scan_interval||300);
            $('#email_enabled').prop('checked', d.email_enabled==='1');
            $('#email_to').val(d.email_to||'');
            $('#email_from').val(d.email_from||'devicemonitor@opnsense.local');
            $('#webhook_enabled').prop('checked', d.webhook_enabled==='1');
            $('#webhook_url').val(d.webhook_url||'');
            buildVlanCheckList('email-vlan-list',   d.email_vlans   || '');
            buildVlanCheckList('webhook-vlan-list', d.webhook_vlans || '');
            toggleEmailConfig();
            toggleWebhookConfig();
        }});
    }

    function toggleEmailConfig() {
        $('#email_enabled').prop('checked') ? $('#email_config').slideDown() : $('#email_config').slideUp();
    }
    function toggleWebhookConfig() {
        $('#webhook_enabled').prop('checked') ? $('#webhook_config').slideDown() : $('#webhook_config').slideUp();
    }
    $('#email_enabled').change(toggleEmailConfig);
    $('#webhook_enabled').change(toggleWebhookConfig);

    function saveConfig($btn) {
        var orig = $btn.html();
        $btn.prop('disabled',true).html('<i class="fa fa-spinner fa-spin"></i> '+translations.saving);
        $.ajax({ url:'/api/devicemonitor/config/set', type:'POST', data:{
            enabled:         $('#enabled').is(':checked')?'1':'0',
            email_enabled:   $('#email_enabled').is(':checked')?'1':'0',
            email_to:        $('#email_to').val(),
            email_from:      $('#email_from').val(),
            email_vlans:     getSelectedVlans('email-vlan-list'),
            webhook_enabled: $('#webhook_enabled').is(':checked')?'1':'0',
            webhook_url:     $('#webhook_url').val(),
            webhook_vlans:   getSelectedVlans('webhook-vlan-list'),
            scan_interval:   $('#scan_interval').val()
        }, success:function(r) {
            $btn.prop('disabled',false).html(orig);
            showToast(r.result==='saved'?translations.config_saved:(r.message||translations.config_error),
                      r.result==='saved'?'success':'error');
        }, error:function() {
            $btn.prop('disabled',false).html(orig);
            showToast(translations.config_error,'error');
        }});
    }

    $('.btn-apply').click(function(){ saveConfig($(this)); });

    $('#btn-test-email').click(function() {
        var email=$('#email_to').val();
        if (!email) { showToast('{{ lang._('Please enter and save recipient email first') }}','error'); return; }
        var $b=$(this), orig=$b.html();
        $b.prop('disabled',true).html('<i class="fa fa-spinner fa-spin"></i>');
        $.ajax({ url:'/api/devicemonitor/config/testemail', type:'POST', success:function(r) {
            $b.prop('disabled',false).html(orig);
            showToast(r.result==='sent'?translations.test_sent+' '+email:(r.message||translations.test_failed),
                      r.result==='sent'?'success':'error');
        }});
    });

    $('#test_webhook').click(function() {
        var url=$('#webhook_url').val();
        if (!url) { $('#webhook_test_result').html('<span style="color:red;">❌ {{ lang._('Enter webhook URL first') }}</span>'); return; }
        $('#webhook_test_result').html('<span style="color:blue;">⏳ {{ lang._('Sending...') }}</span>');
        $.ajax({ url:'/api/devicemonitor/config/testWebhook', type:'POST', data:{webhook_url:url},
            success:function(d) {
                $('#webhook_test_result').html(d.result==='ok'
                    ? '<span style="color:green;">✅ {{ lang._('Test sent!') }}</span>'
                    : '<span style="color:red;">❌ '+(d.message||'{{ lang._('Failed') }}')+'</span>');
            }
        });
    });

    // Load interfaces then config
    $.ajax({ url:'/api/devicemonitor/config/getinterfaces', type:'GET',
        success:function(data){ allVlanNames=data||{}; loadConfig(); },
        error:function(){ loadConfig(); }
    });
});
</script>